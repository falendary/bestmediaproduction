jQuery(document).foundation();

jQuery(document).ready(function() {
  jQuery('.newspage-carousel').slick();
  jQuery('.feedback').trigger("click");
});
